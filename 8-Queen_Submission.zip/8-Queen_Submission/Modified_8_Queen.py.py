# Implementation of a modified 8-queens problem inspired by the N-Queens problem.
# Original code by David Anthony, Swansea University, March 6, 2024.
# Reference: Geeks for Geeks. (2023). 8 queen problem. Retrieved March 6, 2024,
# from https://www.geeksforgeeks.org/8-queen-problem/
# Reference: Harsh, P. (2023, September 30). Exploring Classic Computational Puzzles:
# A Deep Dive into Solving the 8 Queens Problem using Backtracking in Ruby, JavaScript, and Python.
# Medium. Retrieved March 6, 2024, from https://medium.com/cracking-the-coding-interview-in-ruby-python-and/
# 8-12-the-8-queens-problem-with-solutions-ruby-javascript-and-python-409cea33b5b3

import random


def is_safe(board, row, col):
    """Checks if a queen can be placed at the given row and column without attacking
    any other queens on the board.
    """
    # Check row to the left
    for i in range(col):
        if board[row][i] == 'Q':
            return False

    # Check upper diagonal
    i, j = row, col
    while i >= 0 and j >= 0:
        if board[i][j] == 'Q':
            return False
        i -= 1
        j -= 1

    # Check lower diagonal
    i, j = row, col
    while i < 8 and j >= 0:
        if board[i][j] == 'Q':
            return False
        i += 1
        j -= 1

    return True


def solve_n_queens_util(board, col, fixed_row, fixed_col, all_solutions):
    """Recursive helper function to find all solutions using backtracking.
    """
    if col >= 8:
        all_solutions.append([row.copy() for row in board])  # Found a solution, store a copy
        return

    for row in range(8):
        if is_safe(board, row, col):
            board[row][col] = 'Q'

            solve_n_queens_util(board, col + 1, fixed_row, fixed_col, all_solutions)

            # Backtrack
            board[row][col] = '-'


def solve_n_queens(board, fixed_row, fixed_col):
    """Solves for a single solution and all solutions.
    """
    all_solutions = []
    solve_n_queens_util(board, 0, fixed_row, fixed_col, all_solutions)

    if not all_solutions:
        print("No solutions found.")
        return

    for i, solution in enumerate(all_solutions):
        print_board(solution, fixed_row, fixed_col)
        print(f"Solution {i + 1}")
        print("-" * 15)
    print(f"{len(all_solutions)} solutions found")


def print_board(board, fixed_row, fixed_col):
    """Prints the chessboard with the fixed queen highlighted.
    """
    with open('output.txt', 'a') as output_file:
        for i, row in enumerate(board):
            output_file.write(str(i + 1) + " ")
            for j, col in enumerate(row):
                if i == fixed_row - 1 and j == fixed_col - 1:
                    output_file.write('F ')
                else:
                    output_file.write(col + " ")
            output_file.write("\n")
        output_file.write('  ' + ' '.join([str(i + 1) for i in range(8)]) + "\n")


def main():
    """Gets student ID, determines fixed queen position, and calls the solver."""
    student_id = 2145576

    # Calculate fixed queen position (IMPORTANT: Adjust if needed)
    fixed_row = (student_id % 8) + 1  # Extract last digit, convert to 1-based indexing
    fixed_col = ((student_id // 10) % 8) + 1  # Extract second-to-last digit, convert to 1-based

    # Create empty chessboard
    board = [['-' for _ in range(8)] for _ in range(8)]

    # Place fixed queen
    board[fixed_row - 1][fixed_col - 1] = 'Q'

    # Solve for the problem
    solve_n_queens(board, fixed_row, fixed_col)


if __name__ == "__main__":
    main()
